"""Minimal durable key-value Memory; not a semantic vector memory service."""
import sqlite3
from pathlib import Path

class MemoryStore:
    def __init__(self,path):
        self.db=sqlite3.connect(str(path))
        self.db.execute('CREATE TABLE IF NOT EXISTS memory (user_id TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(user_id,key))')
        self.db.commit()

    def save(self,user_id,key,value):
        if not all(isinstance(x,str) and x.strip() for x in (user_id,key,value)):
            raise ValueError('non-empty strings required')
        self.db.execute('INSERT INTO memory(user_id,key,value) VALUES(?,?,?) ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value',(user_id,key,value))
        self.db.commit()

    def read(self,user_id,key):
        row=self.db.execute('SELECT value FROM memory WHERE user_id=? AND key=?',(user_id,key)).fetchone()
        return row[0] if row else None

    def delete(self,user_id,key):
        cur=self.db.execute('DELETE FROM memory WHERE user_id=? AND key=?',(user_id,key))
        self.db.commit()
        return cur.rowcount > 0

    def close(self):self.db.close()
