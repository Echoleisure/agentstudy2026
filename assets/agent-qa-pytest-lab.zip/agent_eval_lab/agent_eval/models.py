from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ToolCall:
    name: str
    arguments: dict[str, Any]
    status: str = "success"


@dataclass
class AgentRun:
    run_id: str
    answer: str
    state: str
    tool_calls: list[ToolCall] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    duration_ms: float = 0
    input_tokens: int = 0
    output_tokens: int = 0
    user_id: str = "user-a"
