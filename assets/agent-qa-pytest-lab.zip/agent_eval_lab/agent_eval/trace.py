from dataclasses import dataclass

@dataclass(frozen=True)
class Span:
    trace_id: str
    span_id: str
    parent_span_id: str | None
    name: str
    start_ms: int
    end_ms: int
    status: str


def validate_trace(spans: list[Span]) -> bool:
    if not spans:
        return False
    ids = [s.span_id for s in spans]
    if len(set(ids)) != len(ids) or len({s.trace_id for s in spans}) != 1:
        return False
    by_id = {s.span_id:s for s in spans}
    roots = [s for s in spans if s.parent_span_id is None]
    if len(roots) != 1:
        return False
    for span in spans:
        if span.end_ms < span.start_ms:
            return False
        if span.parent_span_id is None:
            continue
        parent = by_id.get(span.parent_span_id)
        if parent is None or not (parent.start_ms <= span.start_ms <= span.end_ms <= parent.end_ms):
            return False
        seen = {span.span_id}
        current = parent
        while current is not None:
            if current.span_id in seen:
                return False
            seen.add(current.span_id)
            current = by_id.get(current.parent_span_id) if current.parent_span_id else None
    return True
