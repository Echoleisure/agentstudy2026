"""Tiny SKILL.md validator. Supports a deliberately limited YAML metadata subset.
For full YAML/frontmatter use a compliant parser and skill specification validation.
"""
import re
from pathlib import Path


def load_skill(root):
    root=Path(root).resolve()
    file=root/'SKILL.md'
    raw=file.read_text(encoding='utf-8')
    m=re.match(r'\A---\n(.*?)\n---\n(.*)\Z',raw,re.S)
    if not m: raise ValueError('invalid frontmatter')
    attrs={}
    for line in m.group(1).splitlines():
        if ':' not in line: raise ValueError('unsupported metadata line')
        k,v=line.split(':',1)
        attrs[k.strip()]=v.strip()
    name=attrs.get('name','')
    desc=attrs.get('description','')
    if not re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*',name) or name != root.name or not desc:
        raise ValueError('invalid skill metadata')
    return {'name':name,'description':desc,'instructions':m.group(2).strip(),'root':root}


def read_reference(skill,relative_path):
    root=skill['root']
    target=(root/relative_path).resolve()
    if not target.is_relative_to(root):
        raise PermissionError('path escapes skill root')
    return target.read_text(encoding='utf-8')
