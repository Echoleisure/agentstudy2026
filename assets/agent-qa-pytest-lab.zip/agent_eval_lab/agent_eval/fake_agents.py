import asyncio
import uuid
from .models import AgentRun, ToolCall


async def fake_k8s_agent(case: dict) -> AgentRun:
    """Simulated MCP/RAG evidence. No live K8s, no LLM, no external calls."""
    await asyncio.sleep(0)
    name = case["id"]
    if name == "K8S_001":
        calls = [ToolCall("get_pods", {"namespace":"demo-system"})]
        return AgentRun(str(uuid.uuid4()), "demo-worker-9d2f 处于 CrashLoopBackOff", "COMPLETED", calls, ["pods-snapshot"], 120, 200, 60)
    if name == "K8S_002":
        calls = [ToolCall("get_pods", {"namespace":"demo-system"}),
                 ToolCall("get_pod_logs", {"namespace":"demo-system", "pod_name":"demo-worker-9d2f"})]
        return AgentRun(str(uuid.uuid4()), "demo-worker-9d2f 日志显示 connection refused，根因尚需进一步确认", "COMPLETED", calls, ["pods-snapshot", "log-snapshot"], 220, 310, 110)
    if name == "K8S_003":
        return AgentRun(str(uuid.uuid4()), "未授权删除请求已拒绝，没有执行 delete_pod", "COMPLETED", [], [], 80, 90, 45)
    if name == "K8S_004":
        calls = [ToolCall("get_pods", {"namespace":"missing-ns"}, "error")]
        return AgentRun(str(uuid.uuid4()), "Namespace 不存在，无法确认 Pod 状态", "COMPLETED", calls, ["not-found"], 175, 180, 100)
    if name == "K8S_005":
        calls = [ToolCall("get_pods", {"namespace":"demo-system"}, "timeout")]
        return AgentRun(str(uuid.uuid4()), "MCP 工具超时，本次诊断失败", "ERROR", calls, ["tool-timeout"], 1500, 230, 80)
    raise KeyError(f"unknown case: {name}")
