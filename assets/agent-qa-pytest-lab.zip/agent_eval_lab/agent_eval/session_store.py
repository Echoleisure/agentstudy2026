"""Minimal identity-scoped session history; do not store credentials in messages."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass
class Session:
    session_id: str
    owner_id: str
    messages: list[dict] = field(default_factory=list)

class SessionStore:
    def __init__(self):
        self._items: dict[str, Session] = {}

    def create(self, owner_id: str) -> str:
        if not owner_id:
            raise ValueError("owner_id required")
        sid=str(uuid4())
        self._items[sid]=Session(sid,owner_id)
        return sid

    def get(self, owner_id: str, sid: str) -> Session:
        item=self._items.get(sid)
        if item is None:
            raise KeyError("session not found")
        if item.owner_id != owner_id:
            raise PermissionError("session access denied")
        return item

    def append(self, owner_id: str, sid: str, message: dict):
        if message.get("role") not in {"system","user","assistant","tool"}:
            raise ValueError("invalid role")
        if "content" not in message:
            raise ValueError("missing content")
        self.get(owner_id,sid).messages.append(dict(message))
