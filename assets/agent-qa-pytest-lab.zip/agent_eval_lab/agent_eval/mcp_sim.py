"""Teaching simulator: NOT an MCP implementation or MCP protocol endpoint."""
class ToolArgumentError(ValueError): pass
class BusinessError(RuntimeError): pass


def get_pods(namespace: str) -> list[dict]:
    if not isinstance(namespace,str) or not namespace.strip():
        raise ToolArgumentError('namespace must be non-empty string')
    if namespace == 'missing-ns':
        raise BusinessError('Namespace not found')
    if namespace != 'demo-system':
        return []
    return [{'name':'boson-api-7b8c','status':'Running'},
            {'name':'demo-worker-9d2f','status':'CrashLoopBackOff'}]


def dispatch(name: str, arguments: dict):
    if name != 'get_pods':
        raise KeyError('unknown tool')
    if not isinstance(arguments,dict) or set(arguments) != {'namespace'}:
        raise ToolArgumentError('get_pods requires namespace')
    return get_pods(arguments['namespace'])
