import asyncio


async def pod_agent(namespace: str):
    await asyncio.sleep(0.01)
    return {"namespace": namespace, "pod":"demo-worker-9d2f", "status":"CrashLoopBackOff"}


async def log_agent(pod: str):
    await asyncio.sleep(0.03)
    return {"pod":pod, "evidence":"connection refused"}


async def rag_agent(status: str):
    await asyncio.sleep(0.02)
    return {"symptom":status, "document_id":"runbook-001"}


async def coordinator():
    info = await pod_agent("demo-system")
    logs, knowledge = await asyncio.gather(log_agent(info["pod"]), rag_agent(info["status"]))
    return {"pod":info, "logs":logs, "knowledge":knowledge}


if __name__ == "__main__":
    print(asyncio.run(coordinator()))
