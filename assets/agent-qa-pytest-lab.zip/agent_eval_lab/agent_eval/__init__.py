"""Deterministic Agent E2E evaluation teaching lab."""
