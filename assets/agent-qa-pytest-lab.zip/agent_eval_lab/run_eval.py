"""python run_eval.py --write-report report.json"""
import argparse
import asyncio
import json
from pathlib import Path
from agent_eval.fake_agents import fake_k8s_agent
from agent_eval.evaluator import score_case, summarize

async def run():
    path=Path(__file__).parent/"data"/"golden.json"
    cases=json.loads(path.read_text(encoding="utf-8"))
    rows=[score_case(case,await fake_k8s_agent(case)) for case in cases]
    return {"description":"Deterministic mock lab; no live AgentWorks claims.","summary":summarize(rows),"cases":rows}

if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--write-report",default="")
    args=parser.parse_args()
    report=asyncio.run(run())
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if args.write_report:
        Path(args.write_report).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
