# Agent 平台测试开发：pytest 实战代码包

本项目为**确定性教学 Demo**，不需要 AgentWorks 账号、真实模型、网络连接或 Kubernetes 集群。所有 Pod、日志、RAG 结果均为模拟数据；不能把 Mock 测试通过解释成真实平台质量达标。

## 环境

Python 3.10+；pytest 8/9。

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pytest -q
python run_eval.py --write-report report.json
python -m agent_eval.async_demo
```

## 文件
- `data/golden.json`: 五条结构化任务数据（正常、日志、拒绝删除、不存在 Namespace、MCP 超时）。
- `agent_eval/evaluator.py`: 工具名+参数、顺序、禁止工具、关键事实、证据、状态与用户归属等规则检查；P95 最近秩算法。
- `agent_eval/trace.py`: 单 Trace ID、Span 唯一性、父子关系与时间边界检查。
- `agent_eval/async_demo.py`: 先串行发现异常 Pod，再并发获取日志和 RAG；演示 `await` 和 `gather()`。
- `agent_eval/session_store.py`：会话身份隔离与历史追加。
- `agent_eval/memory_store.py`：SQLite 长期结构化记忆。
- `agent_eval/mcp_sim.py`：MCP 工具语义的最小模拟器，**不是实际 MCP 协议服务**。
- `agent_eval/skill_loader.py`：教学用 Frontmatter 子集解析与路径保护。
- `skills/k8s-diagnosis/`：最小 SKILL.md 与 reference。
- `tests/`: Golden 参数化、工具/参数和禁止动作、P95、Trace、Event 并发屏障、Session/Memory/MCP 模拟与 Skill 加载。

## 局限与下一步
1. `facts_pass` 使用关键词匹配，**不是**语义真实性或 Faithfulness 评分。
2. `tool_match` 采用成员匹配，无法自动判断所有可能的合法轨迹；要求严格顺序时另用 `tool_order`。
3. 安全检查只能验证注入的 Tool Call 记录；真实环境必须校验服务端审计和 K8s 实际资源状态。
4. 模拟 Agent 异步任务不等于 AgentWorks 分布式子代理的运行和取消语义。
5. 真实接入应设计适配器，将 WebSocket `sid/mid/seq` 和主 Agent 终态转换为规范化记录，并结合 Trace 及业务后端验证。
6. 当前没有实现真实 LLM、Ragas、向量 DB、AgentWorks API 或负载发生器，因为缺少可安全访问的测试环境与模型配置。

参考：`https://docs.infini-ai.com/agent-works/reference/websocket-api.html` 与 `https://docs.ragas.io/en/latest/concepts/metrics/available_metrics/`。

## 本次本地验证

在 Python 3 环境运行 `PYTHONPATH=. pytest -q`，结果 **28 passed**。真实的 AgentWorks、LLM、MCP 协议与 Docker 沙箱均未连接或执行。
