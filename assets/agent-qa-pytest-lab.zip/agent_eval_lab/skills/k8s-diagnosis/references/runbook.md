# CrashLoopBackOff
Check Pod status and previous logs, then verify Service, Endpoints and database availability. 'connection refused' alone does not confirm the root cause.
