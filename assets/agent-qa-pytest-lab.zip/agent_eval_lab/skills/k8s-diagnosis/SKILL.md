---
name: k8s-diagnosis
description: Diagnose abnormal Kubernetes Pods using read-only tools
---
# K8s Diagnosis
First get Pod status; then inspect logs; never mutate production resources without explicit authorization.
