from pathlib import Path
import pytest
from agent_eval.session_store import SessionStore
from agent_eval.memory_store import MemoryStore
from agent_eval.mcp_sim import dispatch,ToolArgumentError,BusinessError
from agent_eval.skill_loader import load_skill,read_reference

ROOT=Path(__file__).parents[1]

def test_session_create_and_append():
    st=SessionStore();sid=st.create('u1');st.append('u1',sid,{'role':'user','content':'hello'})
    assert st.get('u1',sid).messages[0]['content']=='hello'

def test_session_cross_user_denied():
    st=SessionStore();sid=st.create('u1')
    with pytest.raises(PermissionError): st.get('u2',sid)

def test_session_bad_role():
    st=SessionStore();sid=st.create('u1')
    with pytest.raises(ValueError): st.append('u1',sid,{'role':'root','content':'bad'})

def test_memory_persists(tmp_path):
    path=tmp_path/'mem.sqlite'
    a=MemoryStore(path);a.save('u1','cluster','demo-system');a.close()
    b=MemoryStore(path);assert b.read('u1','cluster')=='demo-system';b.close()

def test_memory_isolation_update_delete(tmp_path):
    m=MemoryStore(tmp_path/'mem.sqlite')
    m.save('u1','cluster','old');m.save('u1','cluster','new')
    assert m.read('u1','cluster')=='new'
    assert m.read('u2','cluster') is None
    assert m.delete('u1','cluster')
    assert m.read('u1','cluster') is None
    m.close()

def test_memory_reject_empty(tmp_path):
    m=MemoryStore(tmp_path/'mem.sqlite')
    with pytest.raises(ValueError):m.save('u1','','foo')
    m.close()

def test_mock_tool_dispatch():
    pods=dispatch('get_pods',{'namespace':'demo-system'})
    assert any(x['status']=='CrashLoopBackOff' for x in pods)

def test_mock_tool_schema_error():
    with pytest.raises(ToolArgumentError):dispatch('get_pods',{'namespace':123})
    with pytest.raises(ToolArgumentError):dispatch('get_pods',{'wrong':'demo-system'})

def test_mock_tool_business_error():
    with pytest.raises(BusinessError):dispatch('get_pods',{'namespace':'missing-ns'})

def test_skill_load_and_read():
    skill=load_skill(ROOT/'skills'/'k8s-diagnosis')
    assert skill['name']=='k8s-diagnosis'
    assert 'CrashLoopBackOff' in read_reference(skill,'references/runbook.md')

def test_skill_path_escape_blocked():
    skill=load_skill(ROOT/'skills'/'k8s-diagnosis')
    with pytest.raises(PermissionError):read_reference(skill,'../../outside.txt')

def test_skill_missing(tmp_path):
    with pytest.raises(FileNotFoundError):load_skill(tmp_path)
