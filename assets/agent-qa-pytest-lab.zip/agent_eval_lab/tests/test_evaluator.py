import asyncio
import json
from pathlib import Path
import pytest
from agent_eval.evaluator import score_case, summarize, nearest_rank_percentile
from agent_eval.fake_agents import fake_k8s_agent
from agent_eval.models import AgentRun,ToolCall
from agent_eval.trace import Span,validate_trace
from agent_eval.async_demo import coordinator

DATA = json.loads((Path(__file__).parents[1]/"data"/"golden.json").read_text(encoding="utf-8"))

@pytest.mark.parametrize("case",DATA,ids=lambda c:c["id"])
def test_golden(case):
    result = asyncio.run(fake_k8s_agent(case))
    assert score_case(case,result)["passed"]


def test_forbidden_tool_fails():
    case = DATA[2]
    run = AgentRun("r","拒绝", "COMPLETED", [ToolCall("delete_pod",{})])
    assert not score_case(case,run)["safety_pass"]
    assert not score_case(case,run)["passed"]


def test_wrong_namespace_fails():
    case = DATA[0]
    run = AgentRun("r", "demo-worker-9d2f CrashLoopBackOff", "COMPLETED", [ToolCall("get_pods",{"namespace":"other"})], ["pods-snapshot"])
    assert not score_case(case,run)["tool_match"]


def test_order_fails():
    case = DATA[1]
    calls = [ToolCall("get_pod_logs",{"namespace":"demo-system","pod_name":"demo-worker-9d2f"}),ToolCall("get_pods",{"namespace":"demo-system"})]
    run = AgentRun("r","connection refused 尚需进一步确认", "COMPLETED", calls, ["pods-snapshot","log-snapshot"])
    assert not score_case(case,run)["order_pass"]


def test_percentile_nearest_rank():
    assert nearest_rank_percentile([10,20,30,40,50],95) == 50
    with pytest.raises(ValueError):
        nearest_rank_percentile([],95)


def test_summary_separates_run_and_task():
    rows = [dict(passed=False,run_success=True,safety_pass=True,duration_ms=100,tokens=40),
            dict(passed=True,run_success=True,safety_pass=True,duration_ms=200,tokens=60)]
    result = summarize(rows)
    assert result["run_success_rate"] == 1
    assert result["task_success_rate"] == 0.5
    assert result["p95_ms"] == 200


def test_trace_valid():
    spans=[Span("t","root",None,"run",0,200,"OK"),Span("t","model","root","llm",10,50,"OK"),Span("t","tool","root","mcp",60,150,"OK")]
    assert validate_trace(spans)


def test_trace_parent_missing():
    spans=[Span("t","root",None,"run",0,200,"OK"),Span("t","tool","nope","mcp",60,150,"OK")]
    assert not validate_trace(spans)


def test_trace_duplicate_id():
    spans=[Span("t","root",None,"run",0,200,"OK"),Span("t","root","root","bad",30,50,"OK")]
    assert not validate_trace(spans)


def test_async_coordinator():
    result=asyncio.run(coordinator())
    assert result["logs"]["pod"] == result["pod"]["pod"]
    assert result["knowledge"]["document_id"] == "runbook-001"


def test_async_task_timeout():
    async def slow():
        await asyncio.sleep(10)
    async def main():
        with pytest.raises(TimeoutError):
            await asyncio.wait_for(slow(),timeout=0.001)
    asyncio.run(main())


def test_async_concurrency_event():
    async def main():
        both = asyncio.Event()
        started=set()
        async def worker(name):
            started.add(name)
            if len(started)==2: both.set()
            await asyncio.wait_for(both.wait(),timeout=.3)
            return name
        return await asyncio.gather(worker("logs"),worker("rag"))
    assert set(asyncio.run(main())) == {"logs","rag"}
